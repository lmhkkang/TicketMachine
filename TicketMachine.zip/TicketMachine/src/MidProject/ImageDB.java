package MidProject;

import javax.swing.ImageIcon;

public class ImageDB {
	ImageIcon m1 = new ImageIcon(MovieChoiceView.class.getResource("/MidProject/life.jpg"));
	ImageIcon m2 = new ImageIcon(MovieChoiceView.class.getResource("/MidProject/monster.png"));
	ImageIcon m3 = new ImageIcon(MovieChoiceView.class.getResource("/MidProject/po.jpg"));
	ImageIcon m4 = new ImageIcon(MovieChoiceView.class.getResource("/MidProject/endgame.jpg"));
	ImageIcon m5 = new ImageIcon(MovieChoiceView.class.getResource("/MidProject/hotel.jpg"));
	ImageIcon m6 = new ImageIcon(MovieChoiceView.class.getResource("/MidProject/gi.jpg"));
	
	ImageIcon[] imageArray = { null, m1, m2, m3, m4, m5, m6 };
	
}
